package com.epam.rd.autocode.startegy.cards;

import java.util.*;

class ClassicPokerStrategy implements CardDealingStrategy {
    @Override
    public Map<String, List<Card>> dealStacks(Deck deck, int players) {
        Map<String, List<Card>> result = new LinkedHashMap<>();
        
        for (int i = 1; i <= players; i++) {
            result.put("Player " + i, new ArrayList<>());
        }

        // Deal 5 cards to each player in 5 rounds
        for (int round = 0; round < 5; round++) {
            for (int i = 1; i <= players; i++) {
                result.get("Player " + i).add(deck.dealCard());
            }
        }

        result.put("Remaining", deck.restCards());

        return result;
    }
}
