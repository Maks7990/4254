package com.epam.rd.autocode.iterator;

import java.util.Iterator;
import java.util.NoSuchElementException;

class RepeatIterator implements Iterator<Integer> {
    private final int[] array;
    private final int repeatCount;
    private int currentIndex = 0;
    private int repeatCounter = 0;

    public RepeatIterator(int[] array, int repeatCount) {
        this.array = array;
        this.repeatCount = repeatCount;
    }

    @Override
    public boolean hasNext() {
        return currentIndex < array.length;
    }

    @Override
    public Integer next() {
        if (!hasNext()) throw new NoSuchElementException();

        int value = array[currentIndex];
        repeatCounter++;

        if (repeatCounter == repeatCount) {
            currentIndex++;
            repeatCounter = 0;
        }

        return value;
    }
}
