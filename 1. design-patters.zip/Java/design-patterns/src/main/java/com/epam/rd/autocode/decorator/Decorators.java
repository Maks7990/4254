package com.epam.rd.autocode.decorator;

import java.util.AbstractList;
import java.util.Iterator;
import java.util.List;

public class Decorators {
    public static List<String> evenIndexElementsSubList(List<String> sourceList) {
        return new EvenIndexElementsSubList(sourceList);
    }

    private static class EvenIndexElementsSubList extends AbstractList<String> {
        private final List<String> sourceList;

        public EvenIndexElementsSubList(List<String> sourceList) {
            this.sourceList = sourceList;
        }

        @Override
        public String get(int index) {
            return sourceList.get(index * 2);
        }

        @Override
        public int size() {
            return (sourceList.size() + 1) / 2; // To ensure rounding up for odd-length lists
        }

        @Override
        public Iterator<String> iterator() {
            return new Iterator<String>() {
                private int index = 0;

                @Override
                public boolean hasNext() {
                    return index * 2 < sourceList.size();
                }

                @Override
                public String next() {
                    String value = sourceList.get(index * 2);
                    index++;
                    return value;
                }
            };
        }
    }
}
