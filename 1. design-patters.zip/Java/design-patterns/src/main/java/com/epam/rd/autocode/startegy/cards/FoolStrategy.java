package com.epam.rd.autocode.startegy.cards;

import java.util.*;

class FoolStrategy implements CardDealingStrategy {
    @Override
    public Map<String, List<Card>> dealStacks(Deck deck, int players) {
        Map<String, List<Card>> result = new LinkedHashMap<>();

        for (int i = 1; i <= players; i++) {
            result.put("Player " + i, new ArrayList<>());
        }

        for (int round = 0; round < 6; round++) {
            for (int i = 1; i <= players; i++) {
                result.get("Player " + i).add(deck.dealCard());
            }
        }

        // Trump card
        List<Card> trump = new ArrayList<>();
        trump.add(deck.dealCard());
        result.put("Trump card", trump);

        result.put("Remaining", deck.restCards());

        return result;
    }
}
