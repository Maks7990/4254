package com.epam.rd.autocode.startegy.cards;

import java.util.*;

class BridgeStrategy implements CardDealingStrategy {
    @Override
    public Map<String, List<Card>> dealStacks(Deck deck, int players) {
        Map<String, List<Card>> result = new LinkedHashMap<>();

        for (int i = 1; i <= players; i++) {
            result.put("Player " + i, new ArrayList<>());
        }

        for (int round = 0; round < 13; round++) {
            for (int i = 1; i <= players; i++) {
                result.get("Player " + i).add(deck.dealCard());
            }
        }

        return result; // No "Remaining" stack in tests, because deck is empty
    }
}
