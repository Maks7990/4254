package com.epam.rd.autocode;

public interface Named {
    String name();
}
