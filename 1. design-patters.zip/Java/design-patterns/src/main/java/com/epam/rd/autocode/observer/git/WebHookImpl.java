package com.epam.rd.autocode.observer.git;

import java.util.List;
import java.util.ArrayList;

class WebHookImpl implements WebHook {
    private final String branch;
    private final Event.Type type;
    private final List<Event> caught = new ArrayList<>();

    WebHookImpl(String branch, Event.Type type) {
        this.branch = branch;
        this.type = type;
    }

    @Override
    public String branch() {
        return branch;
    }

    @Override
    public Event.Type type() {
        return type;
    }

    @Override
    public List<Event> caughtEvents() {
        return new ArrayList<>(caught);
    }

    @Override
    public void onEvent(Event event) {
        if (event.type() == this.type && event.branch().equals(this.branch)) {
            caught.add(event);
        }
    }
}
