package com.epam.rd.autocode.factory.plot;

import com.epam.rd.autocode.Named;

public interface EpicCrisis extends Named {
}
