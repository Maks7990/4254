package com.epam.rd.autocode.startegy.cards;

import com.epam.rd.autocode.Named;

public interface Card extends Named {
}
