package com.epam.rd.autocode.observer.git;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;
import java.util.stream.Collectors;

class RepositoryImpl implements Repository {
    private final Map<String, List<Commit>> branches = new HashMap<>();
    private final List<WebHook> webHooks = new ArrayList<>();
    private final Map<String, Set<Commit>> merged = new HashMap<>();

    @Override
    public void addWebHook(WebHook webHook) {
        webHooks.add(webHook);
    }

    @Override
    public Commit commit(String branch, String author, String[] changes) {
        Commit commit = new Commit(author, changes);
        branches.computeIfAbsent(branch, k -> new ArrayList<>()).add(commit);
        merged.computeIfAbsent(branch, k -> new HashSet<>()).add(commit);

        Event event = new Event(Event.Type.COMMIT, branch, List.of(commit));
        notifyHooks(event);
        return commit;
    }

    @Override
    public void merge(String sourceBranch, String targetBranch) {
        List<Commit> sourceCommits = branches.getOrDefault(sourceBranch, new ArrayList<>());
        Set<Commit> alreadyMerged = merged.computeIfAbsent(targetBranch, k -> new HashSet<>());
        List<Commit> newCommits = sourceCommits.stream()
                .filter(commit -> !alreadyMerged.contains(commit))
                .collect(Collectors.toList());

        if (!newCommits.isEmpty()) {
            branches.computeIfAbsent(targetBranch, k -> new ArrayList<>()).addAll(newCommits);
            alreadyMerged.addAll(newCommits);
            Event event = new Event(Event.Type.MERGE, targetBranch, newCommits);
            notifyHooks(event);
        }
    }

    private void notifyHooks(Event event) {
        for (WebHook hook : webHooks) {
            hook.onEvent(event);
        }
    }
}

