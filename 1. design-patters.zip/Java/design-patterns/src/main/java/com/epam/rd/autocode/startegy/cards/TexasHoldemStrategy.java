package com.epam.rd.autocode.startegy.cards;

import java.util.*;

class TexasHoldemStrategy implements CardDealingStrategy {
    @Override
    public Map<String, List<Card>> dealStacks(Deck deck, int players) {
        Map<String, List<Card>> result = new LinkedHashMap<>();
        
        // Initialize player hands
        for (int i = 1; i <= players; i++) {
            result.put("Player " + i, new ArrayList<>());
        }

        // Deal 2 cards to each player in 2 rounds
        for (int round = 0; round < 2; round++) {
            for (int i = 1; i <= players; i++) {
                result.get("Player " + i).add(deck.dealCard());
            }
        }

        // Deal 5 community cards
        List<Card> community = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            community.add(deck.dealCard());
        }
        result.put("Community", community);

        // Add remaining cards
        result.put("Remaining", deck.restCards());

        return result;
    }
}
